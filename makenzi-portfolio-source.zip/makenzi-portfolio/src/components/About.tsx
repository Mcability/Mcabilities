import Reveal from "./Reveal";

export default function About() {
  return (
    <section id="about" className="max-w-7xl mx-auto px-5 sm:px-8 py-20 sm:py-28">
      <div className="grid lg:grid-cols-[1fr_1.4fr] gap-10 lg:gap-20">
        <Reveal>
          <p className="font-mono text-xs uppercase tracking-widest text-signal mb-4">About</p>
          <h2 className="font-display font-black uppercase text-3xl sm:text-4xl leading-[0.95]">
            Design has always been about making information work better.
          </h2>
        </Reveal>

        <Reveal delay={0.1} className="space-y-6 text-lg leading-relaxed text-ink/80">
          <p>
            I started where most publication designers start — inside the page. At King's Script
            Publishers and later WordAlive Publishers, I learned typography and print production the
            way it's best learned: under deadline, with real books going to press. That foundation,
            editorial layout, hierarchy, the discipline of getting a manuscript print-ready, still
            shapes how I approach every project today.
          </p>
          <p>
            Over time the scope of what I was solving changed. At Brandworld Communications I moved
            into managing a creative team, coordinating production across print, digital and outdoor
            work for multiple clients at once. At Chrome Partners, and now as Creative Lead at English
            Press Ltd, that responsibility grew into directing creative production end-to-end, owning
            not just individual layouts but the systems and standards that keep a brand consistent
            across every application.
          </p>
          <p>
            Alongside full-time roles, I've kept a consistent freelance and consulting practice since
            2004, designing annual reports and institutional publications for organisations like ILRI,
            developing campaign materials for FMCG brands, and advising publishers on branding
            consistency across their catalogs. It's given me a wide, practical view of what visual
            communication has to do across corporate, publishing and development-sector work.
          </p>
          <p>
            What hasn't changed is the underlying problem I care about: most organisations have
            information that's too complex, too dense or too technical for the audience that needs
            it. My job is to structure that information and give it a visual form people can actually
            engage with — whether that's a stakeholder report, a learning workbook, or a campaign
            reaching thousands of people.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
