import { career, concurrent } from "../data/career";
import Reveal from "./Reveal";

const STAGES = ["Designer", "Specialist", "Manager", "Creative Lead"];

export default function CareerJourney() {
  return (
    <section id="experience" className="max-w-7xl mx-auto px-5 sm:px-8 py-20 sm:py-28">
      <Reveal>
        <p className="font-mono text-xs uppercase tracking-widest text-signal mb-4">Experience</p>
        <h2 className="font-display font-black uppercase text-3xl sm:text-5xl leading-[0.95] max-w-3xl">
          Two decades of creative evolution.
        </h2>
      </Reveal>

      <Reveal delay={0.1} className="flex flex-wrap items-center gap-2 mt-10 font-mono text-xs uppercase tracking-widest text-ink/50">
        {STAGES.map((s, i) => (
          <span key={s} className="flex items-center gap-2">
            <span className={i === STAGES.length - 1 ? "text-signal font-semibold" : ""}>{s}</span>
            {i < STAGES.length - 1 && <span aria-hidden="true">→</span>}
          </span>
        ))}
      </Reveal>

      <ol className="mt-14 divide-y divide-line border-t border-line">
        {career.map((role, i) => (
          <Reveal key={role.company} delay={i * 0.05} className="py-8 sm:py-10">
            <li className="grid sm:grid-cols-[1fr_auto] gap-4 sm:gap-8">
              <div>
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  <h3 className="font-display font-bold uppercase text-xl sm:text-2xl">{role.company}</h3>
                  <span className="font-mono text-xs uppercase tracking-widest text-signal">{role.title}</span>
                </div>
                <ul className="mt-4 space-y-2 max-w-2xl">
                  {role.points.map((p) => (
                    <li key={p} className="text-ink/75 leading-relaxed text-sm sm:text-base">{p}</li>
                  ))}
                </ul>
              </div>
              <div className="font-mono text-sm text-ink/50 sm:text-right whitespace-nowrap">{role.years}</div>
            </li>
          </Reveal>
        ))}
      </ol>

      <Reveal delay={0.1} className="mt-16 pt-10 border-t border-line">
        <p className="font-mono text-xs uppercase tracking-widest text-ink/50 mb-8">
          Concurrent Freelance &amp; Consulting Work
        </p>
        <div className="grid sm:grid-cols-2 gap-8">
          {concurrent.map((c) => (
            <div key={c.title}>
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                <h4 className="font-display font-bold uppercase">{c.title}</h4>
                <span className="font-mono text-xs text-signal">{c.years}</span>
              </div>
              <p className="font-mono text-xs text-ink/50 mt-1 mb-3">{c.org}</p>
              <ul className="space-y-1.5">
                {c.points.map((p) => (
                  <li key={p} className="text-sm text-ink/75 leading-relaxed">{p}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
}
